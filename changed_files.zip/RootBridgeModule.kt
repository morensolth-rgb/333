package com.fridactl

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.os.Build
import com.facebook.react.bridge.*
import com.facebook.react.modules.core.DeviceEventManagerModule
import com.topjohnwu.superuser.Shell
import java.io.File
import java.io.FileOutputStream
import java.io.BufferedInputStream
import java.net.HttpURLConnection
import java.net.URL
import org.apache.commons.compress.compressors.xz.XZCompressorInputStream

class RootBridgeModule(reactContext: ReactApplicationContext) :
    ReactContextBaseJavaModule(reactContext) {

    override fun getName() = "RootBridge"

    // Track whether a download is in progress (survives context reloads)
    private var downloadInProgress = false

    // Lifecycle — clean up receiver when React context tears down
    override fun initialize() {
        super.initialize()
        // If service is still running from before a JS reload, re-attach receiver
        if (downloadInProgress) registerDownloadReceiver()
    }

    override fun onCatalystInstanceDestroy() {
        unregisterDownloadReceiver()
        super.onCatalystInstanceDestroy()
    }

    // ─────────────────────────────────────────────
    // BroadcastReceiver — listens to DownloadService events
    // and forwards them to JS via DeviceEventEmitter
    // ─────────────────────────────────────────────

    private var downloadReceiver: BroadcastReceiver? = null

    private fun registerDownloadReceiver() {
        if (downloadReceiver != null) return // already registered
        downloadReceiver = object : BroadcastReceiver() {
            override fun onReceive(context: Context?, intent: Intent?) {
                when (intent?.action) {
                    DownloadService.ACTION_PROGRESS -> {
                        val binary  = intent.getStringExtra(DownloadService.EXTRA_BINARY) ?: ""
                        val percent = intent.getIntExtra(DownloadService.EXTRA_PERCENT, 0)
                        emitEvent("FridaDownloadProgress", Arguments.createMap().apply {
                            putString("binary", binary)
                            putInt("percent", percent)
                        })
                    }
                    DownloadService.ACTION_DONE -> {
                        downloadInProgress = false
                        val msg = intent.getStringExtra(DownloadService.EXTRA_MESSAGE) ?: ""
                        emitEvent("FridaDownloadDone", Arguments.createMap().apply {
                            putString("message", msg)
                        })
                        unregisterDownloadReceiver()
                    }
                    DownloadService.ACTION_ERROR -> {
                        downloadInProgress = false
                        val msg = intent.getStringExtra(DownloadService.EXTRA_MESSAGE) ?: "Unknown error"
                        emitEvent("FridaDownloadError", Arguments.createMap().apply {
                            putString("message", msg)
                        })
                        unregisterDownloadReceiver()
                    }
                }
            }
        }
        val filter = IntentFilter().apply {
            addAction(DownloadService.ACTION_PROGRESS)
            addAction(DownloadService.ACTION_DONE)
            addAction(DownloadService.ACTION_ERROR)
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            reactApplicationContext.registerReceiver(downloadReceiver, filter, Context.RECEIVER_NOT_EXPORTED)
        } else {
            reactApplicationContext.registerReceiver(downloadReceiver, filter)
        }
    }

    private fun unregisterDownloadReceiver() {
        downloadReceiver?.let {
            try { reactApplicationContext.unregisterReceiver(it) } catch (_: Exception) {}
            downloadReceiver = null
        }
    }

    private fun emitEvent(name: String, params: com.facebook.react.bridge.WritableMap) {
        try {
            // Guard: don't emit if context is no longer alive
            if (!reactApplicationContext.hasActiveCatalystInstance()) return
            reactApplicationContext
                .getJSModule(DeviceEventManagerModule.RCTDeviceEventEmitter::class.java)
                ?.emit(name, params)
        } catch (_: Exception) {}
    }

    companion object {
        private const val FRIDA_PORT     = 27042
        private const val FRIDA_DEST     = "/data/local/tmp/frida-server"
        private const val FRIDA_CLI_DEST = "/data/local/tmp/frida-inject"   // frida-inject binary
        private const val FRIDA_CLI2_DEST= "/data/local/tmp/frida-inject"   // alias — same binary

        init {
            Shell.enableVerboseLogging = false
            Shell.setDefaultBuilder(
                Shell.Builder.create()
                    .setFlags(Shell.FLAG_REDIRECT_STDERR)
                    .setTimeout(60)
            )
        }
    }

    // ─────────────────────────────────────────────
    // Root / shell
    // ─────────────────────────────────────────────

    @ReactMethod
    fun checkRoot(promise: Promise) {
        try {
            val result = Shell.cmd("id").exec()
            promise.resolve(result.out.joinToString("").contains("uid=0"))
        } catch (e: Exception) {
            promise.resolve(false)
        }
    }

    @ReactMethod
    fun execShell(cmd: String, promise: Promise) {
        Thread {
            try {
                val result = Shell.cmd(cmd).exec()
                promise.resolve(result.out.joinToString("\n"))
            } catch (e: Exception) {
                promise.reject("SHELL_ERROR", e.message)
            }
        }.start()
    }

    // ─────────────────────────────────────────────
    // frida-server lifecycle
    // ─────────────────────────────────────────────

    @ReactMethod
    fun startFridaServer(promise: Promise) {
        Thread {
            try {
                // Try embedded asset first, then check if already at dest
                val destFile = File(FRIDA_DEST)
                if (!destFile.exists() || destFile.length() < 1024) {
                    try {
                        extractAsset("frida-server-arm64", FRIDA_DEST)
                    } catch (e: Exception) {
                        throw Exception("frida-server binary not found. Please download it from the Home screen first.")
                    }
                }

                Shell.cmd("pkill -f frida-server 2>/dev/null; true").exec()
                Thread.sleep(500)
                Shell.cmd("chmod 755 $FRIDA_DEST").exec()

                // Use app filesDir for log — /tmp may not exist on all devices
                val fridaLog = "${reactApplicationContext.filesDir}/frida.log"
                Shell.cmd("rm -f '$fridaLog' 2>/dev/null; true").exec()

                // Launch frida-server (no -D flag — not supported on all versions)
                Shell.cmd("$FRIDA_DEST > '$fridaLog' 2>&1 &").exec()
                Thread.sleep(3000)

                if (isFridaServerRunning()) {
                    promise.resolve("frida-server started on port $FRIDA_PORT")
                } else {
                    val log = Shell.cmd("cat '$fridaLog' 2>/dev/null | tail -10").exec().out.joinToString("\n")
                    promise.reject("START_FAILED", "frida-server not responding. Log: $log")
                }
            } catch (e: Exception) {
                promise.reject("START_ERROR", e.message)
            }
        }.start()
    }

    @ReactMethod
    fun stopFridaServer(promise: Promise) {
        try {
            Shell.cmd("pkill -f frida-server").exec()
            promise.resolve(null)
        } catch (e: Exception) {
            promise.reject("STOP_ERROR", e.message)
        }
    }

    @ReactMethod
    fun isFridaRunning(promise: Promise) {
        Thread { promise.resolve(isFridaServerRunning()) }.start()
    }

    private fun isFridaServerRunning(): Boolean {
        return try {
            // /proc/net/tcp on ARM (little-endian) stores port in reversed byte order
            // 27042 = 0x69A2 → stored as A269
            val portBE = String.format("%04X", FRIDA_PORT).uppercase()
            val portLE = String.format("%02X%02X",
                FRIDA_PORT and 0xFF,
                (FRIDA_PORT shr 8) and 0xFF
            ).uppercase()

            // Check /proc/net/tcp (both byte orders), and also ps fallback
            val tcpOut = Shell.cmd(
                "cat /proc/net/tcp6 /proc/net/tcp 2>/dev/null | grep -iE '($portBE|$portLE)'"
            ).exec().out

            if (tcpOut.isNotEmpty()) return true

            // Fallback: check process exists and is running
            val psOut = Shell.cmd("ps -A 2>/dev/null | grep frida-server | grep -v grep").exec().out
            psOut.isNotEmpty()
        } catch (e: Exception) { false }
    }

    // ─────────────────────────────────────────────
    // Download frida binaries at runtime
    // progress callback via events (0-100)
    // ─────────────────────────────────────────────

    @ReactMethod
    fun downloadFridaBinaries(version: String, promise: Promise) {
        // Mark download in progress BEFORE starting service
        downloadInProgress = true
        registerDownloadReceiver()

        val intent = Intent(reactApplicationContext, DownloadService::class.java).apply {
            action = DownloadService.ACTION_START
            putExtra(DownloadService.EXTRA_VERSION, version)
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            reactApplicationContext.startForegroundService(intent)
        else
            reactApplicationContext.startService(intent)

        promise.resolve("Download started in background")
    }

    private fun downloadFile(url: String, dest: String, onProgress: (Int) -> Unit) {
        // Follow redirects manually (GitHub releases redirect to CDN)
        var currentUrl = url
        var conn: HttpURLConnection
        var redirects = 0
        while (true) {
            conn = URL(currentUrl).openConnection() as HttpURLConnection
            conn.connectTimeout = 15000
            conn.readTimeout    = 300000  // 5 min — large binaries on slow connections
            conn.instanceFollowRedirects = false
            conn.setRequestProperty("User-Agent", "FridaCtl/1.0")
            conn.connect()
            val code = conn.responseCode
            if (code in 300..399) {
                val loc = conn.getHeaderField("Location") ?: break
                conn.disconnect()
                currentUrl = loc
                if (++redirects > 10) throw Exception("Too many redirects")
            } else break
        }

        if (conn.responseCode !in 200..299)
            throw Exception("HTTP ${conn.responseCode} for $url")

        val total = conn.contentLengthLong
        var downloaded = 0L
        var lastReported = -1
        val buf = ByteArray(65536)  // 64KB chunks — faster + less GC pressure
        conn.inputStream.use { inp ->
            FileOutputStream(dest).use { out ->
                var n: Int
                while (inp.read(buf).also { n = it } != -1) {
                    out.write(buf, 0, n)
                    downloaded += n
                    if (total > 0) {
                        val pct = ((downloaded * 100) / total).toInt()
                        // Only emit every 2% to avoid flooding the JS bridge
                        if (pct >= lastReported + 2) {
                            lastReported = pct
                            onProgress(pct)
                        }
                    }
                }
            }
        }
        conn.disconnect()
        onProgress(100)
    }

    @ReactMethod
    fun checkBinaries(promise: Promise) {
        val map = Arguments.createMap()
        map.putBoolean("fridaServer", File(FRIDA_DEST).let { it.exists() && it.length() > 1024 })
        map.putBoolean("fridaCli",    File(FRIDA_CLI_DEST).let { it.exists() && it.length() > 1024 })
        map.putBoolean("fridaCli2",   File(FRIDA_CLI_DEST).let { it.exists() && it.length() > 1024 }) // same binary
        map.putString("fridaServerSize", if (File(FRIDA_DEST).exists()) "${File(FRIDA_DEST).length() / 1024}KB" else "missing")
        map.putString("fridaCliSize",    if (File(FRIDA_CLI_DEST).exists()) "${File(FRIDA_CLI_DEST).length() / 1024}KB" else "missing")
        map.putString("fridaCli2Size",   if (File(FRIDA_CLI_DEST).exists()) "${File(FRIDA_CLI_DEST).length() / 1024}KB" else "missing")
        promise.resolve(map)
    }

    // ─────────────────────────────────────────────
    // App listing — ls /data/data via root
    // Gets ALL packages including games
    // ─────────────────────────────────────────────

    @ReactMethod
    fun getInstalledApps(promise: Promise) {
        Thread {
            try {
                val pm = reactApplicationContext.packageManager

                // Method 1: ls /data/data — root sees ALL installed app dirs
                val dataDirResult = Shell.cmd("ls /data/data 2>/dev/null").exec()
                val dataPackages = dataDirResult.out
                    .flatMap { it.trim().split("\\s+".toRegex()) }
                    .filter { it.contains(".") && !it.startsWith(".") }
                    .toMutableSet()

                // Method 2: pm list packages (catches some pm list misses)
                val pmResult = Shell.cmd("pm list packages 2>/dev/null").exec()
                pmResult.out
                    .filter { it.startsWith("package:") }
                    .map { it.removePrefix("package:").trim() }
                    .forEach { dataPackages.add(it) }

                // third-party set
                val thirdParty = Shell.cmd("pm list packages -3 2>/dev/null").exec().out
                    .filter { it.startsWith("package:") }
                    .map { it.removePrefix("package:").trim() }
                    .toSet()

                val arr = WritableNativeArray()

                for (pkg in dataPackages) {
                    if (pkg.isBlank()) continue
                    try {
                        val appInfo = pm.getApplicationInfo(pkg, 0)
                        val appName = pm.getApplicationLabel(appInfo).toString()
                        val isSystem = (appInfo.flags and ApplicationInfo.FLAG_SYSTEM) != 0
                                    && (appInfo.flags and ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) == 0
                                    && !thirdParty.contains(pkg)

                        val map = WritableNativeMap()
                        map.putString("packageName", pkg)
                        map.putString("appName", appName)
                        map.putBoolean("isSystemApp", isSystem)
                        arr.pushMap(map)
                    } catch (_: Exception) {
                        // PM can't resolve it but it exists in /data/data
                        // Show it anyway with raw package name
                        if (pkg.count { it == '.' } >= 1) {
                            val map = WritableNativeMap()
                            map.putString("packageName", pkg)
                            map.putString("appName", pkg.split(".").last()
                                .replaceFirstChar { it.uppercase() })
                            map.putBoolean("isSystemApp", !thirdParty.contains(pkg))
                            arr.pushMap(map)
                        }
                    }
                }

                promise.resolve(arr)
            } catch (e: Exception) {
                promise.reject("APPS_ERROR", e.message)
            }
        }.start()
    }

    // ─────────────────────────────────────────────
    // runScript — attach/spawn via frida CLI binary
    // frida CLI writes console.log to stdout directly
    // → we read inputStream in real-time (no logfile needed)
    // promise resolves once script is loaded; output streams
    // via FridaScriptLog events until process exits / stopScript()
    // ─────────────────────────────────────────────

    // The live frida process — killed by stopScript
    @Volatile private var fridaProcess: Process? = null
    // Legacy compat alias (tail loop uses this to know if we're running)
    @Volatile private var fridaScriptPid: String? = null

    @ReactMethod
    fun stopScript(promise: Promise) {
        Thread {
            fridaScriptPid = null          // signal loops to stop
            fridaProcess?.let { p ->
                try {
                    // Ask frida to exit cleanly first (sends detach)
                    p.outputStream?.let { os ->
                        try { os.write("%resume\n".toByteArray()); os.flush() } catch (_: Exception) {}
                    }
                    Thread.sleep(300)
                    p.destroy()
                } catch (_: Exception) {}
            }
            fridaProcess = null
            emitScriptLog("⏹ Script stopped")
            promise.resolve("stopped")
        }.start()
    }

    @ReactMethod
    fun runScript(packageName: String, script: String, mode: String, promise: Promise) {
        Thread {
            try {
                // ── 1. Ensure frida-inject binary ─────────────────────────────
                val injectFile = File(FRIDA_CLI_DEST)
                if (!injectFile.exists() || injectFile.length() < 1024) {
                    try {
                        extractAsset("frida-inject-arm64", FRIDA_CLI_DEST)
                        emitScriptLog("📦 Extracted frida-inject from assets")
                    } catch (_: Exception) {
                        promise.reject("RUN_ERROR", "frida-inject binary missing — download from Home screen first")
                        return@Thread
                    }
                }
                Shell.cmd("chmod 755 $FRIDA_CLI_DEST").exec()

                // ── 2. Write script to device ─────────────────────────────────
                val scriptPath = "/data/local/tmp/hook_${packageName.replace('.', '_')}.js"
                val tmp = "${reactApplicationContext.filesDir}/hook_tmp.js"
                File(tmp).writeText(script)
                Shell.cmd("cp '$tmp' '$scriptPath' && chmod 644 '$scriptPath'").exec()
                emitScriptLog("📝 Script → $scriptPath")

                // ── 3. Build frida-inject command ─────────────────────────────
                // frida-inject supports: -p PID, -n NAME, -f SPAWN
                // All modes use -U (USB/local), --script for the JS file
                // Output goes to stdout — we stream it via process inputStream
                val logPath = "/data/local/tmp/frida_out_${packageName.replace('.','_')}.log"
                Shell.cmd("rm -f '$logPath' 2>/dev/null; true").exec()

                val cmd: String
                val modeLabel: String
                when (mode) {
                    "spawn" -> {
                        // Kill first, then spawn fresh — cleanest attach
                        Shell.cmd("am force-stop '$packageName' 2>/dev/null; sleep 1; true").exec()
                        // frida-inject spawn: -f package --script file
                        // Wrap in sh -c so we can redirect output to logfile AND stdout
                        cmd = "$FRIDA_CLI_DEST -f '$packageName' --script '$scriptPath'" +
                              " --runtime=v8 2>&1 | tee '$logPath'"
                        modeLabel = "spawn"
                    }
                    "name"  -> {
                        // Attach by name — app must be running
                        cmd = "$FRIDA_CLI_DEST -n '$packageName' --script '$scriptPath'" +
                              " --runtime=v8 2>&1 | tee '$logPath'"
                        modeLabel = "name"
                    }
                    else    -> {   // pid
                        val pid = resolvePid(packageName) ?: run {
                            promise.reject("RUN_ERROR",
                                "Cannot find running process for $packageName — launch it first")
                            return@Thread
                        }
                        cmd = "$FRIDA_CLI_DEST -p $pid --script '$scriptPath'" +
                              " --runtime=v8 2>&1 | tee '$logPath'"
                        modeLabel = "PID $pid"
                    }
                }

                emitScriptLog("🚀 Injecting via frida-inject ($modeLabel)...")
                emitScriptLog("▶ $cmd")

                // ── 4. Launch process & stream output ─────────────────────────
                runFridaProcess(cmd, packageName, promise)

            } catch (e: Exception) {
                promise.reject("RUN_ERROR", e.message)
            }
        }.start()
    }

    // Runs the frida-inject command as a root Process, streams stdout → FridaScriptLog
    private fun runFridaProcess(cmd: String, packageName: String, promise: Promise) {
        // Stop any previous session
        fridaProcess?.destroy()
        fridaProcess = null
        fridaScriptPid = null

        // su -c runs the command as root; sh -c allows pipes (tee) inside the cmd
        val pb = ProcessBuilder("su", "-c", "sh -c \"$cmd\"")
        pb.redirectErrorStream(true)   // stderr → stdout

        val proc: Process
        try {
            proc = pb.start()
        } catch (e: Exception) {
            promise.reject("RUN_ERROR", "Cannot start process: ${e.message}")
            return
        }

        fridaProcess   = proc
        fridaScriptPid = "running"

        var promiseResolved = false

        // ── Stream reader ─────────────────────────────────────────────────────
        Thread {
            try {
                val reader = proc.inputStream.bufferedReader(Charsets.UTF_8)
                var line: String?
                while (reader.readLine().also { line = it } != null) {
                    val l = line ?: break
                    if (l.isBlank()) continue

                    val lLower = l.lowercase()

                    // Filter known noise from frida-inject
                    val isNoise = lLower.contains("tcgetattr") ||
                                  lLower.contains("isatty") ||
                                  lLower.contains("waiting for debugger") ||
                                  lLower.startsWith("frida (") ||
                                  lLower.startsWith("usage:") ||
                                  (lLower.contains("frida") && lLower.contains("version"))
                    if (isNoise) continue

                    emitScriptLog(l)

                    // Detect successful injection signals from frida-inject
                    if (!promiseResolved) {
                        val isSuccess = lLower.contains("spawned") ||
                                        lLower.contains("resumed") ||
                                        lLower.contains("attached") ||
                                        lLower.contains("script loaded") ||
                                        lLower.contains("injected") ||
                                        // frida-inject prints messages directly, so any
                                        // non-error output after startup = success
                                        (!lLower.contains("error") &&
                                         !lLower.contains("failed") &&
                                         !lLower.contains("unable") &&
                                         l.length > 3)
                        if (isSuccess) {
                            promiseResolved = true
                            promise.resolve("running:inject")
                        }
                    }
                }
            } catch (_: Exception) {}

            val exitCode = try { proc.waitFor() } catch (_: Exception) { -1 }
            if (!promiseResolved) {
                promiseResolved = true
                promise.reject("INJECT_ERROR", "frida-inject exited (code $exitCode) — check log above")
            } else {
                emitScriptLog("⏹ Inject process exited (code $exitCode)")
            }
            fridaProcess   = null
            fridaScriptPid = null
        }.start()

        // ── Safety timeout: 10s ───────────────────────────────────────────────
        Thread {
            Thread.sleep(10000)
            if (!promiseResolved) {
                promiseResolved = true
                if (fridaProcess != null) {
                    emitScriptLog("✅ Script presumed running (timeout reached, process alive)")
                    promise.resolve("running:timeout")
                } else {
                    promise.reject("INJECT_ERROR", "frida-inject did not respond within 10 seconds")
                }
            }
        }.start()
    }

    // Resolve PID — launch app if not running, return null if still not found
    private fun resolvePid(packageName: String): String? {
        var pid = Shell.cmd("pidof '$packageName' 2>/dev/null | tr ' ' '\\n' | head -1")
            .exec().out.firstOrNull()?.trim()
        if (!pid.isNullOrBlank()) return pid
        emitScriptLog("⚙ Launching $packageName...")
        Shell.cmd("monkey -p '$packageName' -c android.intent.category.LAUNCHER 1 2>/dev/null").exec()
        Thread.sleep(3000)
        pid = Shell.cmd("pidof '$packageName' 2>/dev/null | tr ' ' '\\n' | head -1")
            .exec().out.firstOrNull()?.trim()
        return pid?.ifBlank { null }
    }

    // Start frida-server if not already running — returns true if server is up
    private fun ensureFridaServer(): Boolean {
        if (isFridaServerRunning()) {
            emitScriptLog("✓ frida-server already running")
            return true
        }
        val dest = File(FRIDA_DEST)
        if (!dest.exists() || dest.length() < 1024) {
            emitScriptLog("ℹ frida-server binary missing")
            return false
        }
        emitScriptLog("⚙ Starting frida-server...")
        val fridaLog = "${reactApplicationContext.filesDir}/frida.log"
        Shell.cmd("chmod 755 $FRIDA_DEST && $FRIDA_DEST > '$fridaLog' 2>&1 &").exec()
        Thread.sleep(3000)
        return if (isFridaServerRunning()) {
            emitScriptLog("✓ frida-server started")
            true
        } else {
            val log = Shell.cmd("tail -3 '$fridaLog' 2>/dev/null").exec().out.joinToString(" | ")
            emitScriptLog("⚠ frida-server failed: $log")
            false
        }
    }

    private fun emitScriptLog(line: String) {
        try {
            if (!reactApplicationContext.hasActiveCatalystInstance()) return
            val params = Arguments.createMap()
            params.putString("line", line)
            reactApplicationContext
                .getJSModule(DeviceEventManagerModule.RCTDeviceEventEmitter::class.java)
                ?.emit("FridaScriptLog", params)
        } catch (_: Exception) {}
    }

    // ─────────────────────────────────────────────
    // File Browser — root access to /data/data
    // ─────────────────────────────────────────────

    @ReactMethod
    fun readDir(path: String, promise: Promise) {
        Thread {
            try {
                // Use find -maxdepth 1 — works better than ls under SELinux
                // Format: TYPE|SIZE|PERMS|NAME  (TYPE=d or f)
                val cmd = "find '$path' -maxdepth 1 -mindepth 1 " +
                    "\\( -type f -o -type d -o -type l \\) " +
                    "-exec stat -c '%F|%s|%A|%n' {} \\; 2>&1"
                val result = Shell.cmd(cmd).exec()

                val arr = WritableNativeArray()
                for (line in result.out) {
                    if (line.isBlank()) continue
                    // stat -c '%F|%s|%A|%n' output: "regular file|1234|drwxr-x--|/path/name"
                    val parts = line.split("|", limit = 4)
                    if (parts.size < 4) continue
                    val fileType = parts[0]
                    val size     = parts[1].toLongOrNull() ?: 0L
                    val perms    = parts[2]
                    val fullPath = parts[3].trim()
                    val name     = fullPath.substringAfterLast("/")
                    if (name.isEmpty() || name == "." || name == "..") continue
                    val isDir = fileType.contains("directory") || fileType.contains("link")
                    val map = WritableNativeMap()
                    map.putString("name", name)
                    map.putString("path", fullPath)
                    map.putBoolean("isDir", isDir)
                    map.putString("size", if (isDir) "" else formatSize(size))
                    map.putString("perms", perms)
                    arr.pushMap(map)
                }

                // If find returned nothing but no error, directory might be empty or inaccessible
                if (arr.size() == 0 && result.out.any { it.contains("Permission denied") || it.contains("Operation not permitted") }) {
                    promise.reject("READ_DIR_ERROR", "Permission denied (SELinux)")
                    return@Thread
                }

                promise.resolve(arr)
            } catch (e: Exception) {
                promise.reject("READ_DIR_ERROR", e.message)
            }
        }.start()
    }

    @ReactMethod
    fun readFile(path: String, promise: Promise) {
        Thread {
            try {
                // Read via root — copy to tmp first then read
                val tmp = "${reactApplicationContext.filesDir}/tmpread"
                Shell.cmd("cp '$path' '$tmp' && chmod 644 '$tmp' 2>&1").exec()
                val f = File(tmp)
                if (!f.exists()) throw Exception("Cannot read file")
                val size = f.length()
                if (size > 512 * 1024) {
                    // Too large — show hex dump header + tail
                    val head = Shell.cmd("xxd '$path' 2>/dev/null | head -32").exec().out.joinToString("\n")
                    promise.resolve("[Binary file — ${formatSize(size)}]\n\n$head\n...(truncated)")
                } else {
                    val content = f.readText()
                    // Check if binary (contains null bytes)
                    if (content.contains('\u0000')) {
                        val hex = Shell.cmd("xxd '$path' 2>/dev/null | head -64").exec().out.joinToString("\n")
                        promise.resolve("[Binary — ${formatSize(size)}]\n\n$hex")
                    } else {
                        promise.resolve(content)
                    }
                }
                f.delete()
            } catch (e: Exception) {
                promise.reject("READ_FILE_ERROR", e.message)
            }
        }.start()
    }

    @ReactMethod
    fun writeFile(path: String, content: String, promise: Promise) {
        Thread {
            try {
                val tmp = "${reactApplicationContext.filesDir}/tmpwrite"
                File(tmp).writeText(content)
                val r = Shell.cmd("cp '$tmp' '$path' 2>&1").exec()
                File(tmp).delete()
                if (!r.isSuccess && r.out.isNotEmpty()) {
                    promise.reject("WRITE_FILE_ERROR", r.out.joinToString("\n"))
                } else {
                    promise.resolve("OK")
                }
            } catch (e: Exception) {
                promise.reject("WRITE_FILE_ERROR", e.message)
            }
        }.start()
    }

    private fun formatSize(bytes: Long): String = when {
        bytes < 1024       -> "${bytes}B"
        bytes < 1024*1024  -> "${bytes/1024}KB"
        else               -> "${"%.1f".format(bytes/1024.0/1024.0)}MB"
    }

    // ─────────────────────────────────────────────
    // XZ extraction via Apache Commons Compress stream
    // frida releases .xz = XZ-compressed raw binary (no tar)
    // We decode the XZ stream manually using the XZ magic bytes
    // ─────────────────────────────────────────────
    private fun extractXz(xzPath: String, outPath: String) {
        File(outPath).delete()

        // Try shell xz first — uses almost zero extra RAM (kernel handles it)
        val xzBin = Shell.cmd("which xz 2>/dev/null || which busybox 2>/dev/null").exec()
            .out.firstOrNull()?.trim()

        if (!xzBin.isNullOrBlank()) {
            val cmd = if (xzBin.contains("busybox"))
                "$xzBin xz -d -k -c '$xzPath' > '$outPath' 2>&1"
            else
                "xz -d -k -c '$xzPath' > '$outPath' 2>&1"
            val r = Shell.cmd(cmd).exec()
            if (File(outPath).exists() && File(outPath).length() > 1024) return
            // shell xz failed — fall through to Java
        }

        // Fallback: Java XZ — stream mode, minimal buffering to reduce RAM pressure
        // Process in 8KB chunks and rely on GC between chunks
        val inBuf = BufferedInputStream(File(xzPath).inputStream(), 8192)
        XZCompressorInputStream(inBuf, true).use { xzIn ->
            FileOutputStream(File(outPath)).use { out ->
                val buf = ByteArray(8192)
                var n: Int
                while (xzIn.read(buf).also { n = it } != -1) {
                    out.write(buf, 0, n)
                }
            }
        }

        if (!File(outPath).exists() || File(outPath).length() < 1024)
            throw Exception("XZ extraction produced empty file")
    }

    // ─────────────────────────────────────────────
    // Asset extraction (from APK assets/)
    // ─────────────────────────────────────────────

    private fun extractAsset(assetName: String, destPath: String, overwrite: Boolean = false) {
        val dest = File(destPath)
        if (!overwrite && dest.exists() && dest.length() > 1024) return
        try {
            reactApplicationContext.assets.open(assetName).use { inp ->
                FileOutputStream(dest).use { out -> inp.copyTo(out) }
            }
            dest.setExecutable(true, false)
        } catch (e: Exception) {
            throw Exception("Missing asset '$assetName'")
        }
    }
}
